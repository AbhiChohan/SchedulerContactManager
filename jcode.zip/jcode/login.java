import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;

class login implements ActionListener
{
    JFrame f1;
    JPanel p1;
    JLabel l1,l2,l3;
    JTextField t1,t2;
    JPasswordField w1;
    JButton b1,b2;
    Connection con;
    PreparedStatement stat1,stat2;
    String s1,s2;
    ResultSet rs1,rs2;

    public login()
    {
        f1=new JFrame("login form");
        p1=new JPanel();
        l1=new JLabel("USERNAME");
        l2=new JLabel("PASSWORD");
        t1=new JTextField(15);
        w1=new JPasswordField(15);t2=new JTextField(15);
        l3=new JLabel("new user");
        b1=new JButton("submit");
        b2=new JButton("login form");
        
            
        f1.getContentPane().add(p1);
        
        
        p1.setBackground(new Color(56,150,226));
        l1.setForeground(new Color(50,40,140));
        l2.setForeground(new Color(50,40,140));
        l3.setForeground(new Color(50,40,140));
        
        p1.add(l1);
        p1.add(t1);
        p1.add(l2);
        p1.add(t2);
        p1.add(b1);
        p1.add(l3);
        p1.add(b2);
        
        f1.setVisible(true);
        f1.setSize(650,500);
        b1.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent evt)
    {
        if(evt.getSource()==b1)
        {
        try
            {
                        
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:pr","sa","");
        
            stat1=con.prepareStatement("select password from users where login_id=?");


		stat1.setString(1,t2.getText());
	rs1=stat1.executeQuery();


	     //rs1=stat1.executeQuery();
            //s1=rs1.setString(1);
            //if(s1=t2.getText());
            mainmenu mm=new mainmenu();

	


            }            
        catch(Exception e)
        {}
        }
    }
    public static void main (String args[])
    {
        login la=new login();
    }
}