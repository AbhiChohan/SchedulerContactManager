import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class searchdetails implements ActionListener
{

    JFrame f;
    JPanel p,p1,p2,p3;
    
    JLabel lid;
    JTextField tid;
    JButton up1,up2,up3;
    
    JLabel lp1,lp2,lp3,lp4,lp5,lp6,lp7,lp8,lp9,lp10,lp11,lp12,lp13,lp14,lp15,lp16,lp17,lp18,lp19,lp20,lp21;
    JTextField tp1,tp2,tp3,tp4,tp5,tp6,tp8,tp9,tp10,tp11,tp12,tp13,tp14,tp15,tp16,tp17,tp18,tp19,tp20,tp21;
    JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
    ButtonGroup grp;
    JRadioButton rb1,rb2;
    Connection con;
    ResultSet result;
    PreparedStatement stat;

    public searchdetails()
    {
    
    
         f=new JFrame();
         p=new JPanel();
         p1=new JPanel();
         p2=new JPanel();
         p3=new JPanel();
        
        p.setLayout(null);
        p1.setLayout(null);
        p2.setLayout(null);
        p3.setLayout(null);
        
        p.setBackground(new Color(56,150,226));
        p1.setBackground(new Color(56,150,226));
        p2.setBackground(new Color(56,150,226));
        p3.setBackground(new Color(56,150,226));
        
        
         f.getContentPane().add(p);
        
        p1.setBounds(40,130,680,430);
        p.add(p1);
        p2.setBounds(40,130,680,430);
        p.add(p2);
        p3.setBounds(40,130,680,430);
        p.add(p3);
        
        
        
         lid=new JLabel("Enter Person ID");
        tid=new JTextField(15);
        
        up1=new JButton("Search Main  >");
        up2=new JButton("Search Home  >");
        up3=new JButton("Search Business  >");
        
        up1.setBackground(new Color(56,150,226));
        up2.setBackground(new Color(56,150,226));
        up3.setBackground(new Color(56,150,226));
        
        
         lid.setBounds(250,20,150,25);
        p.add(lid);
        tid.setBounds(350,20,100,22);
        p.add(tid);
        
        up1.setBounds(130,80,130,25);
        p.add(up1);
        up2.setBounds(275,80,130,25);
        p.add(up2);
        up3.setBounds(420,80,150,25);
        p.add(up3);
        
        
        
        up1.addActionListener(this);
        up2.addActionListener(this);
        up3.addActionListener(this);
        
        
    
/*------------------------ for panel1 --------------------------------*/

        grp=new ButtonGroup();
         rb1=new JRadioButton("Male");
         rb2=new JRadioButton("Female");
        grp.add(rb1);
        grp.add(rb2);
        
            
        lp2=new JLabel("First Name");
        lp3=new JLabel("Last Name");
        lp4=new JLabel("Designation");
        lp5=new JLabel("Date Of Birth");
        lp6=new JLabel("Notes");
        lp7=new JLabel("Sex");
        
        
        tp2=new JTextField(15);
        tp3=new JTextField(15);
        tp4=new JTextField(15);
        tp5=new JTextField(15);
        tp6=new JTextField(15);
        
        
        b2=new JButton("Main");
        b3=new JButton("Exit");
        
        b2.setBackground(new Color(56,150,226));
        b3.setBackground(new Color(56,150,226));
        
        lp2.setBounds(20,100,80,25);
        p1.add(lp2);
        tp2.setBounds(90,100,150,22);
        p1.add(tp2);
        
        lp3.setBounds(20,150,80,25);
        p1.add(lp3);
        tp3.setBounds(90,150,150,22);
        p1.add(tp3);
        
        
        lp4.setBounds(20,200,80,25);
        p1.add(lp4);
        tp4.setBounds(90,200,150,22);
        p1.add(tp4);
        
        
        lp5.setBounds(370,100,80,25);
        p1.add(lp5);
        tp5.setBounds(450,100,150,22);
        p1.add(tp5);
        
        lp7.setBounds(380,170,80,25);
        p1.add(lp7);
        rb1.setBackground(new Color(56,150,226));
        rb2.setBackground(new Color(56,150,226));
        rb1.setBounds(440,160,80,25);
        rb2.setBounds(440,200,80,25);
        p1.add(rb1);
        p1.add(rb2);
        
        
        lp6.setBounds(20,270,80,25);
        p1.add(lp6);
        tp6.setBounds(90,270,500,50);
        p1.add(tp6);
        
        
        b2.setBounds(450,400,80,25);
        p1.add(b2);
        b3.setBounds(540,400,80,25);
        p1.add(b3);
        
        
/*------------------------ for panel2 --------------------------------*/


        lp9=new JLabel("Streen Address");
        lp10=new JLabel("City Name");
        lp11=new JLabel("State Name");
        lp12=new JLabel("Country Name");
        lp13=new JLabel("Zip Code");
        lp14=new JLabel("Details");
        
        
        tp9=new JTextField(15);
        tp10=new JTextField(15);
        tp11=new JTextField(15);
        tp12=new JTextField(15);
        tp13=new JTextField(15);
        tp14=new JTextField(15);
        
        
        
        lp9.setBounds(20,100,100,25);
        p2.add(lp9);
        tp9.setBounds(115,100,500,40);
        p2.add(tp9);
        
        
        lp10.setBounds(20,170,80,25);
        p2.add(lp10);
        tp10.setBounds(110,170,150,25);
        p2.add(tp10);
        
        
        lp11.setBounds(20,220,80,25);
        p2.add(lp11);
        tp11.setBounds(110,220,150,25);
        p2.add(tp11);
        
        
        lp12.setBounds(370,170,80,25);
        p2.add(lp12);
        tp12.setBounds(460,170,150,25);
        p2.add(tp12);
        
        
        lp13.setBounds(370,220,80,25);
        p2.add(lp13);
        tp13.setBounds(460,220,150,25);
        p2.add(tp13);
        
        
        lp14.setBounds(20,270,80,25);
        p2.add(lp14);tp14.setBounds(110,270,500,50);
        p2.add(tp14);
        
        
        
        b5=new JButton("Main");
        b6=new JButton("Exit");
        
        b5.setBackground(new Color(56,150,226));
        b6.setBackground(new Color(56,150,226));
        
        
        b5.setBounds(450,400,80,25);
        p2.add(b5);
        b6.setBounds(540,400,80,25);
        p2.add(b6);        
        
        
        
/*------------------------ for panel3 --------------------------------*/


        lp16=new JLabel("Phone No.");
        lp17=new JLabel("Mobile No.");
        lp18=new JLabel("Fax No.");
        lp19=new JLabel("E-Mail");
        lp20=new JLabel("Website");
        lp21=new JLabel("Details");
        
        
        tp16=new JTextField(15);
        tp17=new JTextField(15);
        tp18=new JTextField(15);
        tp19=new JTextField(15);
        tp20=new JTextField(15);
        tp21=new JTextField(15);
        
        
        lp16.setBounds(20,100,80,25);
        p3.add(lp16);
        tp16.setBounds(90,100,150,22);
        p3.add(tp16);
            
        lp17.setBounds(20,150,80,25);
        p3.add(lp17);
        tp17.setBounds(90,150,150,22);
        p3.add(tp17);
        
        
        lp18.setBounds(20,200,80,25);
        p3.add(lp18);
        tp18.setBounds(90,200,150,22);
        p3.add(tp18);
            
        
        lp19.setBounds(370,100,80,25);
        p3.add(lp19);
        tp19.setBounds(450,100,150,22);
        p3.add(tp19);
        
        
        lp20.setBounds(370,150,80,25);
        p3.add(lp20);
        tp20.setBounds(450,150,150,22);
        p3.add(tp20);
        
        
        lp21.setBounds(20,270,80,25);
        p3.add(lp21);
        tp21.setBounds(90,270,500,50);
        p3.add(tp21);
                
        
        
        b8=new JButton("Main");
        b9=new JButton("Exit");
        
        b8.setBackground(new Color(56,150,226));
        b9.setBackground(new Color(56,150,226));
        
        b8.setBounds(450,400,80,25);
        p3.add(b8);
        b9.setBounds(540,400,80,25);
        p3.add(b9);
        
        
        f.setSize(750,600);
         f.setLocation(140,60);
         f.setVisible(true);
         f.setResizable(false);


        b2.addActionListener(this);
        b3.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        
        p2.setVisible(false);
        p3.setVisible(false);
        
        
    }
        
        
    public void actionPerformed(ActionEvent evt)
    {
        
        if(evt.getSource()==up1)
        {
               
        try
        {    
            
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:project","sa","");
            stat=con.prepareStatement("select * from detail where person_id=?");
            stat.setString(1,tid.getText());
            result=stat.executeQuery();
            result.next();
            tp2.setText(result.getString(2));
            tp3.setText(result.getString(3));
            tp4.setText(result.getString(4));
            tp5.setText(result.getString(5));
            
            p2.setVisible(false);
                   p3.setVisible(false);
                   p1.setVisible(true);            
        }

        catch(Exception ee)
        {
        System.out.println("ERROR OCCURRED" +ee);
        }
        }
    
        if(evt.getSource()==up2)
        {
           try
        {    
            

            stat=con.prepareStatement("select * from home_detail where id=?");
            stat.setString(1,tid.getText());
            result=stat.executeQuery();
            result.next();
            tp9.setText(result.getString(2));
            tp10.setText(result.getString(3));
            tp11.setText(result.getString(4));
            tp12.setText(result.getString(5));
            tp13.setText(result.getString(6));
            
            p1.setVisible(false);
                   p3.setVisible(false);
                p2.setVisible(true);
            }

        catch(Exception ee)
        {
        System.out.println("ERROR OCCURRED" +ee);
        }
        }
    
        if(evt.getSource()==up3)
        {
               
        try
        {    
            

            stat=con.prepareStatement("select * from bsnes_detail where id=?");
            stat.setString(1,tid.getText());
            result=stat.executeQuery();
            result.next();
            tp16.setText(result.getString(2));
            tp17.setText(result.getString(3));
            tp18.setText(result.getString(4));
            tp19.setText(result.getString(5));
            tp20.setText(result.getString(6));
            p1.setVisible(false);
                   p2.setVisible(false);
                   p3.setVisible(true);        
        }

        catch(Exception ee)
        {
        System.out.println("ERROR OCCURRED" +ee);
        }
        }
          
    
        if( (evt.getSource()==b3) || (evt.getSource()==b6) || (evt.getSource()==b9) )
        {
               System.exit(0);

            }


            if( (evt.getSource()==b2) || (evt.getSource()==b5) || (evt.getSource()==b8) )
            {
             
              cmanagermenu cmenu =new cmanagermenu();
                f.setVisible(false);
            }
    


    }


    public static void main(String arg[])
    {
    
     searchdetails srch=new searchdetails();
    }

}

