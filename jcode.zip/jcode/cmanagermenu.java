import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class cmanagermenu implements ActionListener
{

    JPanel p;
    JFrame f;

    JLabel l1,l2,l3,l4,l5,lp1,lp2,lp3,lp4;
    JButton bm,be,b1,b2,b3,b4;
    Font fh,fo,fe;
    Icon ic1,ic2,ic3,ic4;

    public cmanagermenu()
    {

        f=new JFrame();
        p=new JPanel();

        f.getContentPane().add(p);
        p.setBackground(new Color(56,150,226));
        p.setLayout(null);


        fh=new Font("Script MT Bold",Font.BOLD,32);
        fo=new Font("Arial",Font.BOLD,22);
        fe=new Font("Arial",Font.BOLD,12);
        
        ic1=new ImageIcon("c:\\ddicon.png");
        ic2=new ImageIcon("c:\\sch.gif");
        ic3=new ImageIcon("c:\\dlt.png");
        ic4=new ImageIcon("c:\\srch.jpg");

        l1=new JLabel("Contact Manager");
        l1.setFont(fh);
        l1.setForeground(new Color(50,40,140));
        l2=new JLabel("Add Contacts");
        l2.setFont(fo);
        l2.setForeground(new Color(50,40,110));
        l3=new JLabel("Update Contacts");
        l3.setFont(fo);
        l3.setForeground(new Color(50,40,110));
        l4=new JLabel("Delete Contacts");
        l4.setFont(fo);
        l4.setForeground(new Color(50,40,110));
        l5=new JLabel("Search Contacts");
        l5.setFont(fo);
        l5.setForeground(new Color(50,40,110));
    
        lp1=new JLabel(ic1);
        lp2=new JLabel(ic2);
        lp3=new JLabel(ic3);
        lp4=new JLabel(ic4);
    

        bm=new JButton("Main");
        bm.setFont(fe);
        be=new JButton("Exit");
        be.setFont(fe);
        b1=new JButton("Go >");
        b1.setFont(fe);
        b1.setBackground(new Color(90,158,226));
        b2=new JButton("Go >");
        b2.setFont(fe);
        b2.setBackground(new Color(90,158,226));
        b3=new JButton("Go >");
        b3.setFont(fe);
        b3.setBackground(new Color(90,158,226));
        b4=new JButton("Go >");
        b4.setFont(fe);
        b4.setBackground(new Color(90,158,226));
    
    
        l1.setBounds(225,10,250,40);
        p.add(l1);
        l2.setBounds(250,105,200,30);
        p.add(l2);
        l3.setBounds(250,175,200,30);
        p.add(l3);
        l4.setBounds(250,245,200,30);
        p.add(l4);
        l5.setBounds(250,315,200,30);
        p.add(l5);


        lp1.setBounds(150,90,80,80);
        p.add(lp1);
        lp2.setBounds(155,160,80,80);
        p.add(lp2);
        lp3.setBounds(150,225,80,80);
        p.add(lp3);
        lp4.setBounds(150,290,80,80);
        p.add(lp4);
        

        bm.setBounds(15,430,70,25);
        bm.setBackground(new Color(90,158,226));
        bm.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        p.add(bm);

        be.setBounds(90,430,70,25);
        be.setBackground(new Color(90,158,226));
        be.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        p.add(be);

        b1.setBounds( 450,110,70,25);
        p.add(b1);    
        b2.setBounds(450,180,70,25);
        p.add(b2);
        b3.setBounds(450,250,70,25);
        p.add(b3);
        b4.setBounds(450,320,70,25);
        p.add(b4);
    
        be.addActionListener(this);
        bm.addActionListener(this);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        
        f.setSize(700,500);
        f.setLocation(140,60);
        f.setVisible(true);
        f.setResizable(false);
        
        
    }

    public void actionPerformed(ActionEvent evt)
    {
            if(evt.getSource()==be)
            {
                System.exit(0);
        }

        if(evt.getSource()==bm)
           {
                  mainmenu mn=new mainmenu();
                   f.setVisible(false);
           }
        if(evt.getSource()==b1)
        {    
            adddetails ad=new adddetails();
            f.setVisible(false);
        }
        if(evt.getSource()==b2)
        {    
            updatedetails ud=new updatedetails();
            f.setVisible(false);
        }   
        if(evt.getSource()==b3)
        {    
            deletedetails dd=new deletedetails();
            f.setVisible(false);
        }   
        if(evt.getSource()==b4)
        {    
            searchdetails srch=new searchdetails();
            f.setVisible(false);
        }   
    }

    public static void main(String arg[])
    {
           cmanagermenu cm=new cmanagermenu();

    }

}
