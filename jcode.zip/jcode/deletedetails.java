import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class deletedetails implements ActionListener
{

    JFrame f;
    JPanel p;
    JLabel l1;
    JButton b1,b2,b3;
    JTextField t1;
    PreparedStatement stat1,stat2,stat3; 
    Connection con;
    
    public deletedetails()
    {
    
        f=new JFrame();
        p=new JPanel();
        p.setBackground(new Color(56,150,226));
        p.setLayout(null);
        
        f.getContentPane().add(p);
        
        
        l1=new JLabel("Enter Person ID");
        t1=new JTextField(15);
        b1=new JButton("Delete All Details");
        b2=new JButton("Main");
        b3=new JButton("Exit");
        
        
        l1.setBackground(new Color(56,150,226));
        b1.setBackground(new Color(56,150,226));
        b2.setBackground(new Color(56,150,226));
        b3.setBackground(new Color(56,150,226));
        
        
        l1.setBounds(60,100,150,25);
        p.add(l1);
        t1.setBounds(160,100,150,25);
        p.add(t1);
        b1.setBounds(120,160,130,25);
        p.add(b1);
        b2.setBounds(10,340,70,25);
        p.add(b2);
        b3.setBounds(310,340,70,25);
        p.add(b3);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        
        f.setSize(400,400);
        f.setLocation(270,175);
        f.setResizable(false);
        f.setVisible(true);
        
    }

    public void actionPerformed(ActionEvent evt)
    {
        
        if(evt.getSource()==b2)
        {
             cmanagermenu cm=new cmanagermenu();
             f.setVisible(false);
        }
        
         
        if(evt.getSource()==b3)
            {
                  System.exit(0);
            }
  
        if(evt.getSource()==b1);
        {
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:project","sa","");
            stat1=con.prepareStatement("delete from detail where person_id=?");
            stat2=con.prepareStatement("delete from home_detail where id=?");
            stat3=con.prepareStatement("delete from bsnes_detail where id=?");
            stat1.setString(1,t1.getText());
            stat1.executeUpdate();
            stat2.setString(1,t1.getText());
            stat2.executeUpdate();
            stat3.setString(1,t1.getText());
            stat3.executeUpdate();

                }
                  
        catch(Exception ee)
        {
             System.out.println("ERROR OCCURRED" +ee);
        }
        }
        }    
        public static void main(String args[])
    {

         deletedetails dlt=new deletedetails();
        }
}

