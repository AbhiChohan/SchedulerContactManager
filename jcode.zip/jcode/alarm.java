import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import sun.audio.*;


public class alarm implements ActionListener,Runnable
{

    JPanel p;
    JFrame f;
    
    JLabel l1,l5,l6,l7,ltime;
    JTextField t3,t4;
    JButton b3,b4,b7,b8;
    
    Font fnt=new Font("Arial",Font.BOLD,22);
    Font fnt1=new Font("Arial",Font.BOLD,16);
    
    Thread t;
    InputStream in;
    AudioStream as;
    AudioData data;
    ContinuousAudioDataStream cas;

    int h,m;
    Calendar cld= Calendar.getInstance(); 
    String tm,ctm;
    
    public alarm()
    {
        p=new JPanel();
        f=new JFrame();
        p.setBackground(new Color(56,150,226));
        p.setLayout(null);
        
        
        f.getContentPane().add(p);
        
        
        l1=new JLabel("Current Time  -  ");
        l1.setFont(fnt);
        l1.setForeground(new Color(50,40,140));
        
        
        
        l5=new JLabel("Alarm Time");
        l5.setFont(fnt1);
        l6=new JLabel(" Hours");
        l7=new JLabel(" Minutes");
        
        
        
        ltime=new JLabel("");
        ltime.setFont(fnt);
        ltime.setForeground(new Color(50,40,140));
        
        
        
        b3=new JButton("ADD");
        b4=new JButton("Stop");
        
        b7=new JButton("Main");
        b8=new JButton("Exit");
        
        
        
        b3.setBackground(new Color(56,150,226));
        b4.setBackground(new Color(56,150,226));
        b7.setBackground(new Color(56,150,226));
        b8.setBackground(new Color(56,150,226));
        
        
        t3=new JTextField(10);
        t3.setText("0");
        t4=new JTextField(10);
        t4.setText("0");
        
        l1.setBounds(180,10,200,50);
        p.add(l1);
        ltime.setBounds(350,10,200,50);
        p.add(ltime);
        
        
        
        l5.setBounds(30,120,120,50);
        p.add(l5);
        
        l6.setBounds(60,180,120,50);
        p.add(l6);
        t3.setBounds(120,195,70,20);
        p.add(t3);
        
        l7.setBounds(220,180,120,50);
        p.add(l7);
        t4.setBounds(280,195,70,20);
        p.add(t4);
        
        
        
        b3.setBounds(420,190,80,20);
        p.add(b3);
        b4.setBounds(510,190,80,20);
        p.add(b4);
        
        
        b7.setBounds(450,400,80,20);
        p.add(b7);
        b8.setBounds(540,400,80,20);
        p.add(b8);
        
        
        
        t=new Thread(this);
        
        f.setSize(650,470);
            f.setLocation(140,60);
            f.setVisible(true);
            f.setResizable(false);
        
        
        b3.addActionListener(this);
           b4.addActionListener(this);
        
        b7.addActionListener(this);
        b8.addActionListener(this);
        
        
        tm= cld.get(Calendar.HOUR) + "Hr" + " : " + cld.get(Calendar.MINUTE)+"Min";
        
        ltime.setText(tm);
              
    }

    public static void main(String arg[])
    {
           alarm aa=new alarm();
    }
    
    
    public void actionPerformed(ActionEvent evt)
    {
    
        if(evt.getSource()==b7)
              {
            workscheduler work=new workscheduler();
                        f.setVisible(false);
                }

                if(evt.getSource()==b8)
                {
                        System.exit(0);
        
              }
        
        
                if(evt.getSource()==b3)
                {
                        t.start();
                }
                 
          
                if(evt.getSource()==b4)
                {
          
                        t3.setText("");
                        t4.setText("");
                        AudioPlayer.player.stop(cas);
                        m++;
                        t=null;
                }
        
        
        
    }    


    public void run()
    {
        
            try
        {
             in = new FileInputStream("c:\\ding.au");
                }
        catch(Exception exp)
                { }
        
        
        try
        {
                         as = new AudioStream(in);  
        }

        catch(Exception exp)
        {}


        try
        {
             data = as.getData();
        }
        
        catch(Exception exp)
        {}
        
        cas = new ContinuousAudioDataStream (data);
               

            while(t!=null)
            {
                       alarmfun();           

               }   



    }


    public void alarmfun()
        {
            

        h= Integer.parseInt(t3.getText());
            m= Integer.parseInt(t4.getText());
    

            if( (h== cld.get(Calendar.HOUR))  && (m==cld.get(Calendar.MINUTE)) )
                {
                      AudioPlayer.player.start(cas);       
                }

        }


}

