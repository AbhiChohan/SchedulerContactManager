import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class mainmenu implements ActionListener
{

JFrame f;
JPanel p,p1,p2,p3;
JLabel l1,l2,l3,l4,l5,lp1,lp2,lp3,lb;
JButton b5,b1,b2,b3;
Icon ic1,ic2,ic3;

Font fh,fo,fe;

public mainmenu()
{

fh=new Font("Script MT Bold",Font.BOLD,32);
fo=new Font("Arial",Font.BOLD,22);
fe=new Font("Arial",Font.BOLD,12);


ic1=new ImageIcon("c:\\cm.jpg");
ic2=new ImageIcon("c:\\sch.jpg");
ic3=new ImageIcon("c:\\web.jpg");
lp1=new JLabel(ic1);
lp2=new JLabel(ic2);
lp3=new JLabel(ic3);


f=new JFrame();
p=new JPanel();
p1=new JPanel();
p2=new JPanel();
p3=new JPanel();


b5=new JButton("Exit");
b5.setFont(fe);
b1=new JButton("Go >");
b1.setBackground(new Color(90,158,226));
b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
b2=new JButton("Go >");
b2.setBackground(new Color(90,158,226));
b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
b3=new JButton("Go >");
b3.setBackground(new Color(90,158,226));
b3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
b5.setBackground(new Color(90,158,226));
b5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

f.getContentPane().add(p);
p.setBackground(new Color(56,150,226));
p.setLayout(null);
p1.setLayout(null);
p2.setLayout(null);
p3.setLayout(null);
p1.setBackground(new Color(90,158,226));
p2.setBackground(new Color(90,158,226));
p3.setBackground(new Color(90,158,226));

l1=new JLabel("Contact Manager, Scheduler & Browser");
l1.setFont(fh);
l1.setForeground(new Color(50,40,140));
l2=new JLabel("Start Contact Manager");
l2.setFont(fo);
l2.setForeground(new Color(50,40,110));
l3=new JLabel("Start Work Scheduler");
l3.setFont(fo);
l3.setForeground(new Color(50,40,110));
l4=new JLabel("Start Web Browser");
l4.setFont(fo);
l4.setForeground(new Color(50,40,110));
lb=new JLabel("Click on go to start any option.");

p1.setBounds(50,110,520,110);
p.add(p1);
p2.setBounds(130,230,520,110);
p.add(p2);
p3.setBounds(210,350,520,110);
p.add(p3);


l1.setBounds(200,15,450,45);
p.add(l1);
l2.setBounds(200,30,250,25);
p1.add(l2);
lp1.setBounds(10,10,160,90);
p1.add(lp1);
lp2.setBounds(10,10,160,90);
p2.add(lp2);
l3.setBounds(200,30,250,25);
p2.add(l3);
lp3.setBounds(10,10,160,90);
p3.add(lp3);
l4.setBounds(200,30,250,25);
p3.add(l4);
b5.setBounds(700,520,70,25);
p.add(b5);

b1.setBounds(435,30,70,25);
p1.add(b1);
b2.setBounds(435,30,70,25);
p2.add(b2);
b3.setBounds(435,30,70,25);
p3.add(b3);

b5.addActionListener(this);
b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);

f.setLocation(70,40);
f.setResizable(false);
f.setSize(800,580);
f.setVisible(true);

}

public void actionPerformed(ActionEvent evt)
{

   if(evt.getSource()==b5)
     {
         System.exit(0);
     } 


    if(evt.getSource()==b3)
    {
       WebBrowser wb=new WebBrowser();
       f.setVisible(false);
       
    }


     if(evt.getSource()==b2)
    {
     workscheduler work=new workscheduler();
       f.setVisible(false);
       
    }


    if(evt.getSource()==b1)
     {
       cmanagermenu cmng=new cmanagermenu();
       f.setVisible(false);
     }


}
    

public static void main(String args[])
{
    mainmenu mn=new mainmenu();
}

}