import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;

public class deletereminder implements ActionListener
{

    JPanel p;
    JFrame f;
    JLabel vid,vdate,d,m;

    Font foo=new Font("Arial",Font.BOLD,16);

    JTextField t1,td,tm;
    JButton dlt1,dlt2,b1,b2;
    PreparedStatement stat,stat1; 
    Connection con;

    public deletereminder()
    {
        
        p=new JPanel();
        f=new JFrame();
        
        f.getContentPane().add(p);
        
        p.setBackground(new Color(56,150,226));
        p.setLayout(null);
        
        dlt1=new JButton("Delete");
        dlt2=new JButton("Delete");
        dlt1.setBackground(new Color(56,150,226));
        dlt2.setBackground(new Color(56,150,226));
        
        b1=new JButton("Main");
        b2=new JButton("Exit");
        b1.setBackground(new Color(56,150,226));
        b2.setBackground(new Color(56,150,226));
        
        
        vid=new JLabel("Delete Reminder By ID");
        vid.setFont(foo);
        
        vdate=new JLabel("Delete Reminder By Date");
        vdate.setFont(foo);
        
        d=new JLabel("Enter Day");
        m=new JLabel("Enter Month");
        
        t1=new JTextField(20);
        td=new JTextField(20);
        tm=new JTextField(20);
        
        
        vid.setBounds(90,20,300,30);
        p.add(vid);
        t1.setBounds(290,25,80,25);
        p.add(t1);
        
        dlt1.setBounds(470,25,70,25);
        p.add(dlt1);
        
        vdate.setBounds(90,100,300,30);
        p.add(vdate);
        td.setBounds(290,100,50,25);
        p.add(td);
        tm.setBounds(350,100,50,25);
        p.add(tm);
        
        td.setText("day");
        tm.setText("month");
        
        dlt2.setBounds(470,100,70,25);
        p.add(dlt2);
        
        b1.setBounds(500,180,70,25);
        p.add(b1);
        b2.setBounds(580,180,70,25);
        p.add(b2);
        
        
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        dlt1.addActionListener(this);
        dlt2.addActionListener(this);
        
        
        f.setSize(700,270);
            f.setLocation(140,160);
            f.setVisible(true);
        f.setResizable(false);

    }

    public static void main(String arg[])
    {
        deletereminder dlt=new deletereminder();
    }
    
    public void actionPerformed(ActionEvent evt)
    {
    
         if(evt.getSource()==b1)
         {
              workscheduler wrk=new workscheduler();
              f.setVisible(false);
         }

             if(evt.getSource()==b2)
             {
                  System.exit(0);

             }

             if(evt.getSource()==dlt1);
             {
            try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:project","sa","");
            stat=con.prepareStatement("delete from add_rem where date=? AND month=?");
            stat.setString(1,td.getText());
            //stat.executeUpdate();
            stat.setString(2,tm.getText());
            stat.executeUpdate();

                }
                  
        catch(Exception ee)
        {
             System.out.println("ERROR OCCURRED" +ee);
        }
        }
        if(evt.getSource()==dlt2);
        {
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:project","sa","");
            stat1=con.prepareStatement("delete from add_rem where rem_id=?");
            stat1.setString(1,t1.getText());
            stat1.executeUpdate();
            

                }
                  
        catch(Exception ee)
        {
             System.out.println("ERROR OCCURRED" +ee);
        }
        }    

      }


}
