import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class viewreminder implements ActionListener
{

    JFrame f;
    JPanel p;
    JLabel vid,vdate,d,m;
    JTextField t1,t2,td,tm,t3;
    JButton r1,r2;
    JButton b1,b2;
    Connection con;
    ResultSet result;
    PreparedStatement stat;
    
    Font foo=new Font("Arial",Font.BOLD,16);
    
    public viewreminder()
    {
    
        f=new JFrame();
        p=new JPanel();
        p.setBackground(new Color(56,150,226));
        p.setLayout(null);
        f.getContentPane().add(p);
        
        
        vid=new JLabel("View Reminder By ID");
        vid.setFont(foo);
        vdate=new JLabel("View Reminder By Date");
        vdate.setFont(foo);
        r1=new JButton("View");
        r1.setBackground(new Color(56,150,226));
        t1=new JTextField(20);
        t2=new JTextField(200);
        td=new JTextField(20);
        tm=new JTextField(20);
        t3=new JTextField(200);
        d=new JLabel("Enter Day");
        m=new JLabel("Enter Month");
        r2=new JButton("View");
        r2.setBackground(new Color(56,150,226));
        b1=new JButton("Main");
        b2=new JButton("Exit");
        b1.setBackground(new Color(56,150,226));
        b2.setBackground(new Color(56,150,226));
        
        
        
        vid.setBounds(220,20,300,30);
        p.add(vid);
        t1.setBounds(390,25,80,25);
        p.add(t1);
        r1.setBounds(50,80,70,25);
        p.add(r1);
        t2.setBounds(130,70,530,50);
        p.add(t2);
        
        
        vdate.setBounds(250,170,300,30);
        p.add(vdate);
        
        d.setBounds(150,220,100,30);
        p.add(d);
        td.setBounds(220,225,70,20);
        p.add(td);
        m.setBounds(330,220,300,30);
        p.add(m);
        tm.setBounds(410,225,70,20);
        p.add(tm);
        
        r2.setBounds(50,290,70,25);
        p.add(r2);
        t3.setBounds(130,280,530,50);
        p.add(t3);
        
        
        b1.setBounds(570,380,70,25);
        p.add(b1);
        b2.setBounds(650,380,70,25);
        p.add(b2);
        
        
        f.setSize(770,470);
        f.setLocation(140,60);
            f.setVisible(true);
            f.setResizable(false);


            r1.addActionListener(this);
                r2.addActionListener(this);
                b1.addActionListener(this);
                b2.addActionListener(this);


    }


    public void actionPerformed(ActionEvent evt)
    {

                if(evt.getSource()==b1)
                {
                    workscheduler wrk=new workscheduler();
                        f.setVisible(false);
                }

                if(evt.getSource()==b2)
              {
                  System.exit(0);
              }

            if(evt.getSource()==r1)
            {
               
            try
            {    
            
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                con=DriverManager.getConnection("jdbc:odbc:project","sa","");
                stat=con.prepareStatement("select * from add_rem where     rem_id=?");            
                stat.setString(1,t1.getText());
                result=stat.executeQuery();
                result.next();
                
                t2.setText(result.getString(3));
            
                            
            }
    
            catch(Exception ee)
            {
                System.out.println("ERROR OCCURRED" +ee);
            }
        }
            if(evt.getSource()==r2)
            {
               
            try
            {    
            
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                con=DriverManager.getConnection("jdbc:odbc:project","sa","");
                stat=con.prepareStatement("select rem_text from add_rem where date=? and month=?");
                stat.setString(1,td.getText());
                stat.setString(2,tm.getText());
                result=stat.executeQuery();
                result.next();
                t3.setText(result.getString(1));
                                            
            }
    
            catch(Exception ee)
            {
                System.out.println("ERROR OCCURRED" +ee);
            }
        }

    }
    
    public static void main(String arg[])
    {
                viewreminder vr=new viewreminder();
    }


}
